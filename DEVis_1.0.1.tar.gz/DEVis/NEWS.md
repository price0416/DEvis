# DEvis 1.0.1

* Added LFC filtering parameter to de_counts().

# October 17, 2018

DEvis is now available through the CRAN repository. 

# DEvis 1.0.0

Initial release.  
